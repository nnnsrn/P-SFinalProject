import sqlite3
from datetime import datetime

DB_NAME = "stats.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input TEXT,
            mean REAL,
            median REAL,
            mode TEXT,
            std_dev REAL,
            variance REAL,
            timestamp TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_history(input_data, mean, median, mode, std, var):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        INSERT INTO history (input, mean, median, mode, std_dev, variance, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (input_data, mean, median, mode, std, var, datetime.now().isoformat()))
    conn.commit()
    conn.close()
